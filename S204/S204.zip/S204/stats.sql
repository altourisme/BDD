/**
SELECT n2, n3, COUNT(DISTINCT n9)
FROM import
GROUP BY n2, n3
ORDER BY COUNT(DISTINCT n9) DESC
LIMIT 20;
**/

CREATE TEMPORARY TABLE ex1 (nom_prenom VARCHAR(192), sex CHAR(1), Nb_participations int);

INSERT INTO ex1 
SELECT nom_prenom, sex, COUNT(DISTINCT annee)
FROM sportifs NATURAL JOIN ( participations NATURAL JOIN dates)
GROUP BY nom_prenom, sex
ORDER BY COUNT(DISTINCT annee) DESC
LIMIT 20;

\copy ex1 to ex1.csv (format csv, null "NA", DELIMITER ',', HEADER);

/**
SELECT COUNT(DISTINCT n8),AVG(DISTINCT n4),COUNT(DISTINCT n1),MIN(DISTINCT n4),MAX(DISTINCT n4)
FROM import
WHERE n10 = '1996';
**/

CREATE TEMPORARY TABLE ex2a (Pays int, Moyenne_d’âge int, Nb_sportifs  int, Min_âge int, Max_âge int);

INSERT INTO ex2a
SELECT COUNT(DISTINCT pays),AVG(DISTINCT age),COUNT(DISTINCT pno),MIN(DISTINCT age),MAX(DISTINCT age)
FROM team NATURAL JOIN ( (appartient NATURAL JOIN (sportifs NATURAL JOIN participations)) NATURAL JOIN dates)
WHERE annee = '1996' AND saison = 'Summer';

\copy ex2a to ex2a.csv (format csv, null "NA", DELIMITER ',', HEADER);

/**
SELECT AVG(DISTINCT n4)
FROM import
WHERE n10 = '1996' AND n15 IS NOT NULL;
**/
SELECT AVG(age)
FROM (
SELECT age
FROM participations NATURAL JOIN dates
WHERE annee = '1996' AND saison = 'Summer' AND medaille IS NOT NULL
GROUP BY pno,age) age_par_personne;

SELECT AVG(age)
FROM (
SELECT age
FROM participations NATURAL JOIN dates
WHERE annee = '1996' AND saison = 'Summer'
GROUP BY pno,age) age_par_personne;

/**
SELECT AVG(n6) AS MOY_POIDS_MALE
FROM import
WHERE n10 = '1996' AND n3='M';
**/

SELECT AVG(poids) AS MOY_POIDS_MALE
FROM (
SELECT poids
FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
WHERE annee = '1996' AND saison = 'Summer' AND sex='M'
GROUP BY pno,poids) poids_par_personne;

/*
SELECT AVG(poids) AS MOY_POIDS_MALE
FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
WHERE annee = '1996' AND sex='M';
*/
/**
SELECT AVG(n6) AS MOY_POIDS_MALE_with_MEDAL
FROM import
WHERE n10 = '1996' AND n3='M' AND n15 IS NOT NULL;
**/

SELECT AVG(poids) AS MOY_POIDS_MALE_with_MEDAL
FROM (
SELECT poids
FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
WHERE annee = '1996' AND saison = 'Summer' AND sex='M' AND medaille IS NOT NULL
GROUP BY pno,poids) poids_par_personne;

/*
SELECT AVG(poids) AS MOY_POIDS_MALE_with_MEDAL
FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
WHERE annee = '1996' AND sex='M' AND medaille IS NOT NULL;
*/
/**
SELECT AVG(n6) AS MOY_POIDS_FEMM
FROM import
WHERE n10 = '1996' AND n3='F';
**/

SELECT AVG(poids) AS MOY_POIDS_FEMM
FROM (
SELECT poids
FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
WHERE annee = '1996' AND saison = 'Summer' AND sex='F'
GROUP BY pno,poids) poids_par_personne;

/*
SELECT AVG(poids) AS MOY_POIDS_FEMM
FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
WHERE annee = '1996' AND sex='F';
*/
/**
SELECT AVG(n6) AS MOY_POIDS_FEMM_with_MEDAL
FROM import
WHERE n10 = '1996' AND n3='F' AND n15 IS NOT NULL;
**/

SELECT AVG(poids) AS MOY_POIDS_FEMM_with_MEDAL
FROM (
SELECT poids
FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
WHERE annee = '1996' AND saison = 'Summer' AND sex='F' AND medaille IS NOT NULL
GROUP BY pno,poids) poids_par_personne;

/*
SELECT AVG(poids) AS MOY_POIDS_FEMM_with_MEDAL
FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
WHERE annee = '1996' AND sex='F' AND medaille IS NOT NULL;
*/
/**
SELECT n8,COUNT(*)
FROM import
WHERE n10 <= 2016 AND n10 >= 1992 AND n3='F' AND n15 IS NOT NULL
GROUP BY n8
ORDER BY COUNT(*) DESC
LIMIT 15;
**/

CREATE TEMPORARY TABLE ex3a (Pays VARCHAR(192), Nb_médailles int);

INSERT INTO ex3a
SELECT pays,COUNT(*)
FROM team NATURAL JOIN (dates NATURAL JOIN (appartient NATURAL JOIN (sportifs NATURAL JOIN participations)))
WHERE annee <= 2016 AND annee >= 1992 AND medaille IS NOT NULL
GROUP BY pays
ORDER BY COUNT(*) DESC
LIMIT 15;

\copy ex3a to ex3a.csv (format csv, null "NA", DELIMITER ',', HEADER);

/**
3b
USA
Russia
UK
Italy
France
**/

/**i**/
CREATE TEMPORARY TABLE ex3bi (Annee int, Pays VARCHAR(192), Nb_participations int);

INSERT INTO ex3bi
SELECT annee, pays, COUNT(DISTINCT pno) AS nb_participant
FROM team NATURAL JOIN (dates NATURAL JOIN (appartient NATURAL JOIN (sportifs NATURAL JOIN participations)))
WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy')
GROUP BY annee,pays
ORDER BY annee ASC, pays ASC;

\copy ex3bi to ex3bi.csv (format csv, null "NA", DELIMITER ',', HEADER);

/**ii**/
CREATE TEMPORARY TABLE ex3bii (Annee int, Pays VARCHAR(192), Nb_médaillés int);

INSERT INTO ex3bii
SELECT annee, pays, COUNT(DISTINCT pno) AS nb_médaillés
FROM team NATURAL JOIN ((dates NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND medaille IS NOT NULL
GROUP BY annee,pays
ORDER BY annee ASC, pays ASC;

\copy ex3bii to ex3bii.csv (format csv, null "NA", DELIMITER ',', HEADER);

/**iii**/
CREATE TEMPORARY TABLE ex3biii (Annee int, Pays VARCHAR(192), Nb_femme int);

INSERT INTO ex3biii
SELECT annee, pays, COUNT(DISTINCT pno) AS nb_femme
FROM team NATURAL JOIN ((dates NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='F'
GROUP BY annee,pays
ORDER BY annee ASC, pays ASC;

\copy ex3biii to ex3biii.csv (format csv, null "NA", DELIMITER ',', HEADER);

/**iv**/
CREATE TEMPORARY TABLE ex3biv (Annee int, Pays VARCHAR(192), Proportion_femme_Participant float);

INSERT INTO ex3biv
SELECT annee, pays, (COUNT(DISTINCT pno)::FLOAT/(SELECT COUNT(DISTINCT pno) 
FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE d1.annee=d2.annee AND p1.pays=p2.pays)::FLOAT)*100 AS nb_proportion_femme
FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='F'
GROUP BY annee,pays
ORDER BY annee ASC, pays ASC;

INSERT INTO ex3biv
SELECT annee, pays, (COUNT(DISTINCT pno)::FLOAT/(SELECT COUNT(DISTINCT pno) 
FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE d1.annee=d2.annee AND p1.pays=p2.pays)::FLOAT)*100 AS nb_proportion_femme
FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='M'
GROUP BY annee,pays
ORDER BY annee ASC, pays ASC;

\copy ex3biv to ex3biv.csv (format csv, null "NA", DELIMITER ',', HEADER);

/**v**/
CREATE TEMPORARY TABLE ex3bv (Annee int, Pays VARCHAR(192), Proportion_femme_médaillés float);

INSERT INTO ex3bv
SELECT annee, pays, (COUNT(DISTINCT pno)::FLOAT/(SELECT COUNT(DISTINCT pno) 
FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE d1.annee=d2.annee AND p1.pays=p2.pays AND sex='F')::FLOAT)*100 AS nb_proportion_femme
FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='F' AND medaille IS NOT NULL
GROUP BY annee,pays
ORDER BY annee ASC, pays ASC;

INSERT INTO ex3bv
SELECT annee, pays, 100-(COUNT(DISTINCT pno)::FLOAT/(SELECT COUNT(DISTINCT pno) 
FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE d1.annee=d2.annee AND p1.pays=p2.pays AND sex='F')::FLOAT)*100 AS nb_proportion_femme
FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='F' AND medaille IS NOT NULL
GROUP BY annee,pays
ORDER BY annee ASC, pays ASC;

\copy ex3bv to ex3bv.csv (format csv, null "NA", DELIMITER ',', HEADER);

/**vi**/
CREATE TEMPORARY TABLE ex3bvi (Annee int, Pays VARCHAR(192), Proportion_femme_médaillés float);

INSERT INTO ex3bvi
SELECT annee, pays, (COUNT(DISTINCT pno)::FLOAT/(SELECT COUNT(DISTINCT pno) 
FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE d1.annee=d2.annee AND p1.pays=p2.pays AND medaille IS NOT NULL)::FLOAT)*100 AS nb_proportion_femme
FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='F' AND medaille IS NOT NULL
GROUP BY annee,pays
ORDER BY annee ASC, pays ASC;

INSERT INTO ex3bvi
SELECT annee, pays, (COUNT(DISTINCT pno)::FLOAT/(SELECT COUNT(DISTINCT pno) 
FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE d1.annee=d2.annee AND p1.pays=p2.pays AND medaille IS NOT NULL)::FLOAT)*100 AS nb_proportion_femme
FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='M' AND medaille IS NOT NULL
GROUP BY annee,pays
ORDER BY annee ASC, pays ASC;

\copy ex3bvi to ex3bvi.csv (format csv, null "NA", DELIMITER ',', HEADER);



/****/
SELECT AVG(cnt) AS moyenne_participation_JO
FROM (
  SELECT COUNT(DISTINCT annee) AS cnt
  FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
  GROUP BY nom_prenom, sex
) AS participation_JO;

SELECT VARIANCE(nb_participant_par_pays)
FROM(
SELECT COUNT(DISTINCT pno) AS nb_participant_par_pays
FROM team NATURAL JOIN ( (appartient NATURAL JOIN (sportifs NATURAL JOIN participations)) NATURAL JOIN dates)
WHERE annee = '1996' AND saison = 'Summer'
GROUP BY pays) AS participant_Pays;

WITH participant_Pays AS (
  SELECT COUNT(DISTINCT pno) AS nb_participant_par_pays
  FROM team NATURAL JOIN ((appartient NATURAL JOIN (sportifs NATURAL JOIN participations)) NATURAL JOIN dates)
  WHERE annee = '1996' AND saison = 'Summer'
  GROUP BY pays
)
SELECT
  PERCENTILE_DISC(0.25) WITHIN GROUP (ORDER BY nb_participant_par_pays) AS premier_quartile,
  PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY nb_participant_par_pays) AS mediane,
  PERCENTILE_DISC(0.75) WITHIN GROUP (ORDER BY nb_participant_par_pays) AS troisieme_quartile
FROM
  participant_Pays;

/**   
SELECT COUNT(DISTINCT pno) AS nb_participant_par_pays
FROM team NATURAL JOIN ( (appartient NATURAL JOIN (sportifs NATURAL JOIN participations)) NATURAL JOIN dates)
WHERE annee = '1996' AND saison = 'Summer'
GROUP BY pays
**/

WITH participation_JO AS (
  SELECT COUNT(DISTINCT annee) AS cnt
  FROM sportifs NATURAL JOIN (participations NATURAL JOIN dates)
  GROUP BY nom_prenom, sex
)
SELECT
  PERCENTILE_DISC(0.25) WITHIN GROUP (ORDER BY cnt) AS premier_quartile,
  PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY cnt) AS mediane,
  PERCENTILE_DISC(0.75) WITHIN GROUP (ORDER BY cnt) AS troisieme_quartile
FROM
  participation_JO;
  
  
WITH age_par_personne AS (
  SELECT age
  FROM participations NATURAL JOIN dates
  WHERE annee = '1996' AND saison = 'Summer' AND medaille IS NOT NULL
  GROUP BY pno, age
)
SELECT
  PERCENTILE_DISC(0.25) WITHIN GROUP (ORDER BY age) AS premier_quartile,
  PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY age) AS mediane,
  PERCENTILE_DISC(0.75) WITHIN GROUP (ORDER BY age) AS troisieme_quartile
FROM
  age_par_personne;


WITH age_par_personne AS (
  SELECT age
  FROM participations NATURAL JOIN dates
  WHERE annee = '1996' AND saison = 'Summer'
  GROUP BY pno, age
)
SELECT
  PERCENTILE_DISC(0.25) WITHIN GROUP (ORDER BY age) AS premier_quartile,
  PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY age) AS mediane,
  PERCENTILE_DISC(0.75) WITHIN GROUP (ORDER BY age) AS troisieme_quartile
FROM
  age_par_personne;
  
SELECT VARIANCE(medaille_par_pays)
FROM( SELECT COUNT(*) AS medaille_par_pays
FROM team NATURAL JOIN (dates NATURAL JOIN (appartient NATURAL JOIN (sportifs NATURAL JOIN participations)))
WHERE annee <= 2016 AND annee >= 1992 AND medaille IS NOT NULL
GROUP BY pays) variance_medaille;


WITH proportion_femmes AS (
  SELECT pays, (COUNT(DISTINCT pno)::FLOAT / (SELECT COUNT(DISTINCT pno)
                                             FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
                                             WHERE d1.annee=d2.annee AND p1.pays=p2.pays)::FLOAT) * 100 AS nb_proportion_femme
  FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
  WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='F'
  GROUP BY annee, pays
)

SELECT pays, COALESCE(STDDEV(nb_proportion_femme), 0) AS ecart_type
FROM proportion_femmes
GROUP BY pays;

WITH proportion_femmes AS (
  SELECT pays, (COUNT(DISTINCT pno)::FLOAT / (SELECT COUNT(DISTINCT pno)
                                             FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
                                             WHERE d1.annee=d2.annee AND p1.pays=p2.pays AND sex='F')::FLOAT) * 100 AS nb_proportion_femme
  FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
  WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='F' AND medaille IS NOT NULL
  GROUP BY annee, pays
)

SELECT pays, COALESCE(STDDEV(nb_proportion_femme), 0) AS ecart_type
FROM proportion_femmes
GROUP BY pays;

SELECT pays, AVG(nb_proportion_femme) AS moyenne_proportion_femme
FROM (
  SELECT pays, (COUNT(DISTINCT pno)::FLOAT / (SELECT COUNT(DISTINCT pno)
                                             FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
                                             WHERE d1.annee=d2.annee AND p1.pays=p2.pays AND sex='F')::FLOAT) * 100 AS nb_proportion_femme
  FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
  WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='F' AND medaille IS NOT NULL
  GROUP BY annee, pays
) AS proportions
GROUP BY pays;


SELECT pays, STDDEV(nb_proportion_femme) AS ecart_type_proportion_femme
FROM (
  SELECT pays, (COUNT(DISTINCT pno)::FLOAT / (SELECT COUNT(DISTINCT pno)
                                             FROM team p2 NATURAL JOIN ((dates d2 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
                                             WHERE d1.annee=d2.annee AND p1.pays=p2.pays AND medaille IS NOT NULL)::FLOAT) * 100 AS nb_proportion_femme
  FROM team p1 NATURAL JOIN ((dates d1 NATURAL JOIN (appartient NATURAL JOIN sportifs)) NATURAL JOIN participations)
  WHERE annee <= 2016 AND annee >= 1992 AND (pays = 'France' OR pays = 'USA' OR pays = 'Russia' OR pays = 'UK' OR pays = 'Italy') AND sex='F' AND medaille IS NOT NULL
  GROUP BY annee, pays
) AS proportions
GROUP BY pays;

