DROP TABLE IF EXISTS import,noc;


/* Exercice2 Q1 */

CREATE TEMPORARY TABLE import (n1 text, n2 text, n3 CHAR(3), n4 INT, n5 NUMERIC(5,2), n6 NUMERIC(5,2), n7 text, n8 CHAR(5), n9 text, n10 INT, n11 text,n12 text, n13 text, n14 text, n15 text);


/* Exercice Q2 */

\copy import from athlete_events.csv (format csv, null "NA", DELIMITER ',', HEADER);


/* Exercice2 Q3 */

DELETE FROM import
WHERE n10 < 1920 OR n13 LIKE 'Art%';
SELECT COUNT(*) AS count_row_import
FROM import;


/* Exercice2 Q4 */

CREATE TEMPORARY TABLE noc (n1 CHAR(3), n2 text, n3 text);

\copy noc from noc_regions.csv (format csv, null "NA", DELIMITER ',',HEADER);

SELECT COUNT(*) AS count_row_noc
FROM noc;

/* Exercice4 Q1 */

DROP TABLE IF EXISTS appartient,dates,evenements,participations,sportifs,sports,team,villes;

/*==============================================================*/
/* Table : APPARTIENT                                           */
/*==============================================================*/
create table appartient (
   tno                  CHAR(3)              not null,
   dno                  INT                  not null,
   pno                  INT                  not null,
   constraint PK_APPARTIENT primary key (tno, pno, dno)
);

/*==============================================================*/
/* Table : DATE                                                 */
/*==============================================================*/
create table dates (
   dno                  SERIAL                 not null,
   annee                INT                    null
   CHECK(annee%2=0),
   saison               CHAR(6)                null
   CHECK(saison='Winter' OR saison='Summer'),
   constraint PK_DATE primary key (dno)
);

/*==============================================================*/
/* Table : EVENEMENTS                                           */
/*==============================================================*/
create table evenements (
   eno                  SERIAL               not null,
   vno                  INT                  not null,
   sno                  INT                  not null,
   nom                  VARCHAR(256)         null,
   constraint PK_EVENEMENTS primary key (eno)
);

/*==============================================================*/
/* Table : PARTICIPATIONS                                       */
/*==============================================================*/
create table participations (
   pno                  INT                  not null,
   eno                  INT                  not null,
   dno                  INT                  not null,
   medaille             VARCHAR(6)           null
   CHECK(medaille='Gold' OR medaille='Silver' OR medaille='Bronze'),
   age                  INT                  null,
   taille               INT                  null,
   poids                INT                  null,
   constraint PK_PARTICIPATION primary key (pno, eno, dno)
);

/*==============================================================*/
/* Table : SPORTIFS                                             */
/*==============================================================*/
create table sportifs (
   pno                  SERIAL               not null,
   nom_prenom           VARCHAR(128)         null,
   sex                  CHAR(1)              null,
   constraint PK_SPORTIFS primary key (pno)
);

/*==============================================================*/
/* Table : SPORTS                                               */
/*==============================================================*/
create table sports (
   sno                  SERIAL               not null,
   sport                VARCHAR(256)         null,
   constraint PK_SPORTS primary key (sno)
);

/*==============================================================*/
/* Table : TEAM                                                 */
/*==============================================================*/
create table team (
   tno                  CHAR(3)              not null,
   pays                 VARCHAR(128)         null,
   libelle              VARCHAR(256)         null,
   constraint PK_TEAM primary key (tno)
);

/*==============================================================*/
/* Table : VILLES                                               */
/*==============================================================*/
create table villes
(
   vno                  SERIAL                         not null,
   ville                VARCHAR(128)                   null,
   constraint PK_VILLES primary key (vno)
);

alter table appartient
   add constraint FK_APPARTIE_APPARTIEN_DATES foreign key (dno)
      references dates (dno)
      on update restrict
      on delete restrict;

alter table appartient
   add constraint FK_APPARTIE_APPARTIEN_TEAM foreign key (tno)
      references team (tno)
      on update restrict
      on delete restrict;

alter table appartient
   add constraint FK_APPARTIE_APPARTIEN_SPORTIFS foreign key (pno)
      references sportifs (pno)
      on update restrict
      on delete restrict;

alter table evenements
   add constraint FK_EVENEMEN_A_LIEUX_A_VILLES foreign key (vno)
      references villes (vno)
      on update restrict
      on delete restrict;

alter table evenements
   add constraint FK_EVENEMEN_PRATIQUE_SPORTS foreign key (sno)
      references sports (sno)
      on update restrict
      on delete restrict;

alter table participations
   add constraint FK_PARTICIP_PARTICIPA_EVENEMEN foreign key (eno)
      references evenements (eno)
      on update restrict
      on delete restrict;
      
alter table participations
   add constraint FK_PARTICIP_PARTICIPA_DATES foreign key (dno)
      references dates (dno)
      on update restrict
      on delete restrict;

alter table participations
   add constraint FK_PARTICIP_PARTICIPA_SPORTIFS foreign key (pno)
      references sportifs (pno)
      on update restrict
      on delete restrict;

 
INSERT INTO dates(annee,saison)
SELECT DISTINCT n10,n11
FROM import;

INSERT INTO sports(sport)
SELECT DISTINCT n13
FROM import;

INSERT INTO sportifs(pno,nom_prenom,sex)
SELECT DISTINCT n1::integer,n2,n3
FROM import;

INSERT INTO villes(ville)
SELECT DISTINCT n12
FROM import;

INSERT INTO team(tno,pays,libelle)
 SELECT DISTINCT n1,n2,n3
FROM noc;

INSERT INTO evenements(sno,nom,vno)
SELECT DISTINCT sno,n14,vno
FROM villes JOIN (import JOIN sports ON n13=sport) ON n12=ville;

INSERT INTO appartient(tno,dno,pno)
SELECT DISTINCT tno,dno,pno
FROM dates JOIN ( team JOIN ( import JOIN sportifs ON CAST(n1 AS INT)=pno) ON tno=n8) ON annee=n10 AND saison=n11;

INSERT INTO participations(pno,eno,dno,medaille,age,taille,poids)
SELECT DISTINCT pno,eno,dno,n15,n4,n5,n6
FROM evenements e JOIN (villes v JOIN (dates JOIN (import JOIN sportifs ON CAST(n1 AS INT)=pno) ON annee=n10 AND saison=n11) ON ville=n12) ON nom=n14 AND e.vno=v.vno ;
      
/* Exercice4 Q2 */
      
SELECT pg_table_size('import') AS size_table_import ;

SELECT pg_table_size('evenements')+pg_table_size('participations')+pg_table_size('team')+pg_table_size('sportifs')+pg_table_size('dates')+pg_table_size('sports')+pg_table_size('appartient')+pg_table_size('villes') AS SUM_all_size_table ;


/* Exercice4 Q3 */

\copy evenements to evenements.csv (format csv, null "NA", DELIMITER ',', HEADER);
\copy participations to participations.csv (format csv, null "NA", DELIMITER ',', HEADER);
\copy team to team.csv (format csv, null "NA", DELIMITER ',', HEADER);
\copy sportifs to sportifs.csv (format csv, null "NA", DELIMITER ',', HEADER);
\copy dates to dates.csv (format csv, null "NA", DELIMITER ',', HEADER);
\copy sports to sports.csv (format csv, null "NA", DELIMITER ',', HEADER);
\copy appartient to appartient.csv (format csv, null "NA", DELIMITER ',', HEADER);
\copy villes to appartient.csv (format csv, null "NA", DELIMITER ',', HEADER);
