/* Exercice3 Q1 */
/* Combien de colonnes dans import ? (1 valeur) */

SELECT COUNT(*) AS nb_column_import
FROM INFORMATION_SCHEMA.COLUMNS
WHERE table_catalog = 'but1'
AND table_name = 'import';


/* Exercice3 Q2 */
/* Combien de lignes dans import ? (1 valeur) */

SELECT COUNT(*) AS nb_row_import
FROM import;


/* Exercice3 Q3 */
/* Combien de codes NOC dans noc ? (1 valeur) */

SELECT COUNT(n1) AS nb_noc
FROM noc;


/* Exercice3 Q4 */
/* Combien d’athletes différents sont référencés dans ce fichier (1 valeur) */

SELECT COUNT(DISTINCT n2) AS nb_athletes_import
FROM import
WHERE n13 = 'Athletics';


/* Exercice3 Q5 */
/* Combien y-a t-il de médailles d’or dans ce fichier ?(1 valeur) */

SELECT COUNT(n15) AS nb_gold_import
FROM import
WHERE n15 = 'Gold';


/* Exercice3 Q6 */
/* Retrouvez Carl Lewis; Combien de lignes se réfèrent à Carl Lewis ? (1 valeur) */

SELECT COUNT(*) AS nb_row_Carl_Lewis
FROM import
WHERE n2 = 'Carl Lewis Borack';


/* Exercice5 Q1 */
/* Liste des pays classés par participation aux épreuves (2 cols) */

SELECT pays,nom
FROM team JOIN (appartient JOIN (participations JOIN evenements USING(eno)) USING(pno)) USING(tno)
GROUP BY pays,nom
ORDER BY nom ASC,COUNT(*) DESC;


/* Exercice5 Q2 */
/* Liste des pays classés par nombre de médailles d’or (2 cols) */

SELECT pays,COUNT(*) AS nb_gold
FROM team JOIN (appartient JOIN participations USING(pno)) USING(tno)
WHERE medaille='Gold'
GROUP BY pays
ORDER BY COUNT(*) DESC;


/* Exercice5 Q3 */
/* Liste des pays classés par nombre médailles totales (2 cols) */

SELECT pays,COUNT(*) AS nb_gold
FROM team JOIN (appartient JOIN participations USING(pno)) USING(tno)
WHERE medaille IS NOT NULL
GROUP BY pays
ORDER BY COUNT(*) DESC;


/* Exercice5 Q4 */
/* Liste des sportifs ayant le plus de médailles d’or, avec le nombre (3 cols) */

SELECT nom_prenom,sex,COUNT(*) AS nb_gold
FROM sportifs JOIN participations USING(pno)
WHERE medaille='Gold'
GROUP BY nom_prenom,sex
ORDER BY COUNT(*) DESC;


/* Exercice5 Q5 */
/* Nombre de médailles cumulées par pays pour les Jeux d’Albertville, par ordre décroissant (2 cols) */

SELECT pays,COUNT(*) AS nb_medal_for_albertville
FROM team JOIN (appartient JOIN (dates JOIN (participations JOIN (evenements JOIN villes USING (vno)) USING(eno)) USING(dno)) USING(dno,pno)) USING (tno)
WHERE medaille IS NOT NULL AND ville='Albertville'
GROUP BY pays
ORDER BY COUNT(*) DESC;


/* Exercice5 Q6 */
/* Combien de sportifs ont fait les jeux olympiques sous 2 drapeaux différents, le dernier étant la France ? (1 valeur) */

SELECT COUNT(DISTINCT a1.pno) AS nb_sportifs_diff_team_first_is_french
FROM (appartient a1 JOIN dates d1 ON d1.dno=a1.dno) JOIN (appartient a2 JOIN dates d2 ON d2.dno=a2.dno) ON a1.pno=a2.pno
WHERE a1.tno!=a2.tno AND a2.tno='FRA' AND CAST(d1.annee AS VARCHAR(6))||d1.saison > CAST(d2.annee AS VARCHAR(6))||d2.saison;

/* Selon vous quel est le plus connu/célèbre/titré/... ? */

SELECT pno,nom_prenom,sex,COUNT(medaille)
FROM sportifs NATURAL JOIN participations
WHERE pno IN (SELECT DISTINCT a1.pno
FROM (appartient a1 JOIN dates d1 ON d1.dno=a1.dno) JOIN (appartient a2 JOIN dates d2 ON d2.dno=a2.dno) ON a1.pno=a2.pno
WHERE a1.tno!=a2.tno AND a2.tno='FRA' AND CAST(d1.annee AS VARCHAR(6))||d1.saison > CAST(d2.annee AS VARCHAR(6))||d2.saison)
GROUP BY pno,nom_prenom,sex;
/* D'après cette requête la personne la plus célébre serait Julien Bahain */


/* Exercice5 Q7 */
/* Combien de sportifs ont fait les jeux olympiques sous 2 drapeaux différents, le premier étant la France ? (1 valeur)*/

SELECT COUNT(DISTINCT a1.pno) AS nb_sportifs_diff_team_last_is_french
FROM (appartient a1 JOIN dates d1 ON d1.dno=a1.dno) JOIN (appartient a2 JOIN dates d2 ON d2.dno=a2.dno) ON a1.pno=a2.pno
WHERE a1.tno!=a2.tno AND a2.tno='FRA' AND CAST(d1.annee AS VARCHAR(6))||d1.saison < CAST(d2.annee AS VARCHAR(6))||d2.saison;


/* Selon vous quel est le plus connu/célèbre/titré/... ? */

SELECT pno,nom_prenom,sex,COUNT(medaille)
FROM sportifs NATURAL JOIN participations
WHERE pno IN (SELECT DISTINCT a1.pno
FROM (appartient a1 JOIN dates d1 ON d1.dno=a1.dno) JOIN (appartient a2 JOIN dates d2 ON d2.dno=a2.dno) ON a1.pno=a2.pno
WHERE a1.tno!=a2.tno AND a2.tno='FRA' AND CAST(d1.annee AS VARCHAR(6))||d1.saison < CAST(d2.annee AS VARCHAR(6))||d2.saison)
GROUP BY pno,nom_prenom,sex;
/* D'après cette requête la personne la plus célébre serait Angelo Parisi */


/* Exercice5 Q8 */
/* Distribution des âges des médaillés d’or (2 cols) */

SELECT age,COUNT(*) AS nb_medal_Gold
FROM participations
WHERE medaille='Gold'
GROUP BY age;


/* Exercice5 Q9 */
/* Distribution des disciplines donnant des médailles aux plus de 50 ans par ordre décroissant (2 cols) */

SELECT sport,COUNT(*) AS nb_medal_for_more_50_year
FROM participations NATURAL JOIN (evenements NATURAL JOIN sports)
WHERE medaille='Gold' AND age>50
GROUP BY sport
ORDER BY COUNT(*) DESC;


/* Exercice5 Q10 */
/* Nombre d’épreuves par type de jeux (hivers,été), par année croissante (3 cols) */

SELECT annee,saison,COUNT(DISTINCT sno) AS nb_games_by_event
FROM dates NATURAL JOIN (participations NATURAL JOIN evenements)
GROUP BY saison,annee
ORDER BY annee ASC;


/* Exercice5 Q11 */
/* Nombre de médailles féminines aux jeux d’été par année croissante (2 cols) */

SELECT annee,COUNT(*) AS nb_medal_women_summer_games
FROM dates NATURAL JOIN (participations NATURAL JOIN sportifs)
WHERE sex='F' AND medaille IS NOT NULL
GROUP BY annee
ORDER BY annee ASC;


/* Exercice6  */
/* Sport: athlète */
/* Pays: Finlande */

/* Annee de participations avec nombre de participants et de médailles gagnés*/
SELECT annee,COUNT(*) AS nb_participations,(SELECT COUNT(*) FROM sports NATURAL JOIN ( evenements NATURAL JOIN (participations NATURAL JOIN (dates d2 NATURAL JOIN (appartient NATURAL JOIN team)))) WHERE medaille IS NOT NULL AND pays='Finland' AND sport='Athletics' AND d1.annee=d2.annee AND sport='Athletics' GROUP BY annee) AS nb_medaille
FROM sports NATURAL JOIN ( evenements NATURAL JOIN (participations NATURAL JOIN (dates d1 NATURAL JOIN (appartient NATURAL JOIN team))))
WHERE pays='Finland' AND sport='Athletics'
GROUP BY annee
ORDER BY annee ASC;

/* Sportifs avec nombre de participations */
SELECT nom_prenom,sex,COUNT(*) AS nb_participations
FROM sports NATURAL JOIN ( evenements NATURAL JOIN (participations NATURAL JOIN (sportifs NATURAL JOIN (appartient NATURAL JOIN team))))
WHERE pays='Finland' AND sport='Athletics'
GROUP BY nom_prenom,sex
ORDER BY nom_prenom,sex;

/* Nombres de médaille d'or , argent et bronze par participants */
SELECT DISTINCT nom_prenom,sex,(SELECT COUNT(*) FROM sports NATURAL JOIN ( evenements NATURAL JOIN (participations NATURAL JOIN (sportifs s2 NATURAL JOIN (appartient NATURAL JOIN team)))) WHERE s1.pno=s2.pno AND pays='Finland' AND sport='Athletics' AND medaille='Gold' GROUP BY s2.pno) AS nb_Gold,(SELECT COUNT(*) FROM sports NATURAL JOIN ( evenements NATURAL JOIN (participations NATURAL JOIN (sportifs s2 NATURAL JOIN (appartient NATURAL JOIN team)))) WHERE s1.pno=s2.pno AND pays='Finland' AND sport='Athletics' AND medaille='Silver' GROUP BY s2.pno) AS nb_Silver,(SELECT COUNT(*) FROM sports NATURAL JOIN ( evenements NATURAL JOIN (participations NATURAL JOIN (sportifs s2 NATURAL JOIN (appartient NATURAL JOIN team)))) WHERE s1.pno=s2.pno AND pays='Finland' AND sport='Athletics' AND medaille='Bronze' GROUP BY s2.pno) AS nb_Bronze
FROM sports NATURAL JOIN ( evenements NATURAL JOIN (participations NATURAL JOIN (sportifs s1 NATURAL JOIN (appartient NATURAL JOIN team))))
WHERE pays='Finland' AND sport='Athletics'
ORDER BY nom_prenom,sex;

/* Nombre de participants par evenement */
SELECT DISTINCT nom,(SELECT COUNT(*) FROM sports NATURAL JOIN ( evenements e2 NATURAL JOIN (participations NATURAL JOIN (sportifs NATURAL JOIN (appartient NATURAL JOIN team)))) WHERE pays='Finland' AND sport='Athletics' AND e1.nom=e2.nom) AS nb_Participants
FROM sports NATURAL JOIN ( evenements e1 NATURAL JOIN (participations NATURAL JOIN (sportifs NATURAL JOIN (appartient NATURAL JOIN team))))
WHERE pays='Finland' AND sport='Athletics'
GROUP BY nom
HAVING COUNT(*)>0
ORDER BY nom;

SELECT DISTINCT nom_prenom,sex
FROM sportifs NATURAL JOIN participations
GROUP BY nom,sex,annee
ORDER BY COUNT(*)
LIMIT 20;
